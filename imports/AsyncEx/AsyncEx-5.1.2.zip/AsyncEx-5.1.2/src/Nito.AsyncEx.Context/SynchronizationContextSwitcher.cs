﻿using System.Runtime.CompilerServices;

[assembly: TypeForwardedTo(typeof(Nito.AsyncEx.SynchronizationContextSwitcher))]
