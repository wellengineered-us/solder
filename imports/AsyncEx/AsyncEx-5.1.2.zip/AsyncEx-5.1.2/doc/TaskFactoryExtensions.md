## Overview

`TaskFactoryExtensions` provides a series of `Run` overloads for scheduling `async` as well as synchronous delegates.
