## Overview

An `AsyncProducerConsumerQueue` is a queue of items that provides `async`-compatible *Enqueue* and *Dequeue* operations. [AsyncCollection](AsyncCollection.md) is more flexible than this type, but it is also more complex.
