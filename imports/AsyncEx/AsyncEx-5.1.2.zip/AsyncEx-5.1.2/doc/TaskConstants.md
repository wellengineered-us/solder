## Overview

Task constants provide pre-constructed constant task values. These are effective when using the [async fast path](https://blogs.msdn.microsoft.com/lucian/2011/04/15/async-ctp-refresh-design-changes/).
