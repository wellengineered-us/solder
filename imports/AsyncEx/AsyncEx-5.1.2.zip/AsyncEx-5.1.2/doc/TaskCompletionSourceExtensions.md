## Overview

`TaskCompletionSourceExtensions` provides extension methods for the `TaskCompletionSource<T>` type.

To forward the result of one `Task` to another, call `TryCompleteFromCompletedTask`.
