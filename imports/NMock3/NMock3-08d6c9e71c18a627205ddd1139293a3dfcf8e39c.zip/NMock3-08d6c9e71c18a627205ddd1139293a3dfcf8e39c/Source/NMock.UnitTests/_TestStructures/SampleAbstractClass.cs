﻿namespace NMockTests._TestStructures
{
	public abstract class SampleAbstractClass
	{
		public abstract int Add(int a, int b);
	}
}