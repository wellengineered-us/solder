﻿namespace NMockTests._TestStructures
{
	public interface IAmAMarkerInterface
	{
	}
}