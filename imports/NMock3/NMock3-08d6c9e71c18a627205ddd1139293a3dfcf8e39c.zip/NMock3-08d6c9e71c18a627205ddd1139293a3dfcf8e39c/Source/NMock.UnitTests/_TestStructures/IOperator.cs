﻿namespace NMockTests._TestStructures
{
	public interface IOperator
	{
		IChildInterface Get();
	}
}