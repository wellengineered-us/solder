Assemblies in this folder are the result of the ILMerge tool.

The NMock3.dll is the NMock3.dll + the Castle dlls.

Please do not check them into source control.  They need to be built without checking them out.