﻿namespace NMockTests._TestStructures
{
	public interface INamed
	{
		string GetName();
	}
}