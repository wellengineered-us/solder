﻿namespace NMockTests._TestStructures
{
	public interface IMockedType
	{
		void Method();
		void DoStuff();

	}
}