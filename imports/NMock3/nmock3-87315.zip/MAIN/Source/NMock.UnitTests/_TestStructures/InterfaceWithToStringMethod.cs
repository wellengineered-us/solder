﻿namespace NMockTests._TestStructures
{
	public interface InterfaceWithToStringMethod
	{
		string ToString();
	}
}