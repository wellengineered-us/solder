﻿namespace NMockTests._TestStructures
{
	public interface IamAreturnValue
	{
		void SayHi();
	}
}