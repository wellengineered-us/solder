﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NMockTests._TestStructures
{
	public enum ContactType
	{
		Employee,
		Customer,
		Personal,
		Vendor,
	}
}
