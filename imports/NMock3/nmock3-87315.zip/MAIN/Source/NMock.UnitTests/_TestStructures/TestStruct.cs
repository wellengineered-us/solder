﻿namespace NMockTests._TestStructures
{
	public struct TestStruct
	{
		public int X;
		public int Y;
	}
}