namespace NMock.AcceptanceTests
{
	public interface IHelloWorld
	{
		void Hello();
		void Umm();
		void Err();
		void Ahh();
		void Goodbye();
		string Ask(string question);
	}
}