﻿namespace NMockTests._TestStructures
{
	public interface IServiceOne
	{
		string ServiceOneGetsName();
	}
}
