﻿namespace NMockTests._TestStructures
{
	public enum TestValues
	{
		None = 0,
		First = 1,
		Second = 2,
	}
}