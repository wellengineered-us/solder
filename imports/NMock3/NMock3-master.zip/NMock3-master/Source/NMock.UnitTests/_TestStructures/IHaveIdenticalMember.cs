﻿namespace NMockTests._TestStructures
{
	public interface IHaveIdenticalMember
	{
		int DoSomething(); // Same member as on IHaveAllMemberTypes
	}
}