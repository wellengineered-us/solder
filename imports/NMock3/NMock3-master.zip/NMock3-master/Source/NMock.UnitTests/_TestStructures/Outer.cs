﻿namespace NMockTests._TestStructures
{
	public class Outer
	{
		public const string CONST = "Constant";

		public Inner Inner { get; set; }
	}
}