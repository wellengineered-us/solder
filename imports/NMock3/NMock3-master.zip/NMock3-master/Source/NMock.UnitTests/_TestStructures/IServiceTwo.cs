namespace NMockTests._TestStructures
{
	public interface IServiceTwo
	{
		bool ServiceTwoSaves();
	}
}