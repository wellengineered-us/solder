﻿using System;

namespace NMock3.Tutorial
{
	public interface IViewBase
	{
		event EventHandler Init;
	}
}
